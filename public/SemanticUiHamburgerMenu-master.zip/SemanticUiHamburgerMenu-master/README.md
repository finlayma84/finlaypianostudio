# Semantic UI: Hamburger Menu
This repo is sponsored by www.phpninja.info Web Repair Services.

Author: @betoayesa 

Disclaimer: I understand why Semantic UI creators doesn't want to add this type of features to the project's core. I respect the nature of Semantic UI project because I love it. But I need a Hamburger Menu. Maybe you too.

An .ui.menu.stackable with hamburger icon.

![](screenshot.png?raw=true)

After hamburger icon is clicked.

![](screenshot2.png?raw=true)

## How to enable it
- Add Hamburger HTML to your .UI.MENU
- Add class "stackable" to your menu
- Include JS and CSS lines

## License

Lincensed under MIT License terms





